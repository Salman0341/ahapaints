=== Custom Cursor ===
Contributors:      GutenbergHub
Tags:              cursor, custom, follow content,
Tested up to:      6.2
Stable tag:        1.0.0
License:           GPL-2.0-or-later
License URI:       https://www.gnu.org/licenses/gpl-2.0.html

Create custom cursors for your WordPress site with ease. Choose from image or text cursors, and add engaging follow content.

== Description ==

Create custom cursors for your WordPress site with ease. Choose from image or text cursors, and add engaging follow content.