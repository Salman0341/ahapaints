<?php
/**
 * Plugin Name:       	Custom Cursor
 * Description:       	Create custom cursors for your WordPress site with ease. Choose from image or text cursors, and add engaging follow content.
 * Requires PHP:      	7.5
 * Requires at least: 	6.2
 * Version:           	1.0.0
 * Author:            	GutenbergHub
 * Author URI:		  	https://shop.gutenberghub.com/
 * License:           	GPL-2.0-or-later
 * License URI:       	https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       	gutenberghub-custom-cursor
 *
 */


if (!defined('ABSPATH')) {
	die('No direct access');
}

if (!defined('GHUB_CUSTOM_CURSOR_URL')) {
	define('GHUB_CUSTOM_CURSOR_URL', plugins_url('/', __FILE__));
}

if (!defined('GHUB_CUSTOM_CURSOR_PATH')) {
	define('GHUB_CUSTOM_CURSOR_PATH', plugin_dir_path(__FILE__));
}

if (!class_exists('Gutenberghub_Custom_Cursor')) {
	/**
	 * Main plugin class
	 */
	final class Gutenberghub_Custom_Cursor {

		/**
		 * Constructor
		 *
		 * @return void
		 */
		public function __construct() {
			add_action('init', array($this, 'register_scripts'));
			add_filter('render_block', array($this, 'render_block'), 10, 3);
			add_filter('register_block_type_args', array($this, 'custom_block_args'), 10, 1);

			require_once GHUB_CUSTOM_CURSOR_PATH . "includes/function.php";
			require_once GHUB_CUSTOM_CURSOR_PATH . 'gutenberghub-sdk/loader.php';
		}
		public function register_scripts() {
			\wp_register_script(
				"ghub-custom-cursor-script",
				GHUB_CUSTOM_CURSOR_URL . 'build/index.js',
				array(
					"wp-element",
					"wp-compose",
					"wp-hooks",
					"wp-block-editor",
					"wp-i18n"
				),
				uniqid()
			);

			\wp_register_style(
				'ghub-custom-cursor-editor-style',
				GHUB_CUSTOM_CURSOR_URL . 'build/index.css',
				array(),
				uniqid()
			);
			\wp_register_style(
				'ghub-custom-cursor-frontend-style',
				GHUB_CUSTOM_CURSOR_URL . 'build/style-index.css',
				array(),
				uniqid()
			);
			\wp_register_script(
				'ghub-custom-cursor-frontend-script',
				GHUB_CUSTOM_CURSOR_URL . 'scripts/frontend.js',
				array(),
				uniqid()
			);
		}
		public function custom_block_args($args) {
			$enqueued_styles = isset($args['editor_style']) ? $args['editor_style'] : array();
			$enqueued_scripts = isset($args['editor_script']) ? $args['editor_script'] : array();
			$current_provided_editor_style = isset($args['editor_style_handles']) ? $args['editor_style_handles'] : array();
			$current_provided_editor_scripts = isset($args['editor_script_handles']) ? $args['editor_script_handles'] : array();

			if(!empty($enqueued_scripts)){
				if(is_array($enqueued_scripts)){
					$current_provided_editor_scripts = array_merge($current_provided_editor_scripts, $enqueued_scripts);
				} else if(is_string($enqueued_scripts)){
					$current_provided_editor_scripts = array_merge($current_provided_editor_scripts, array($enqueued_scripts));
				}
			}
			
			if(!empty($enqueued_styles)){
				if(is_array($enqueued_styles)){
					$current_provided_editor_style = array_merge($current_provided_editor_style, $enqueued_styles);
				} else if(is_string($enqueued_styles)){
					$current_provided_editor_style = array_merge($current_provided_editor_style, array($enqueued_styles));
				}
			}

			$args['editor_style_handles'] = array_merge($current_provided_editor_style, array('ghub-custom-cursor-editor-style'));
			$args['editor_script_handles'] = array_merge($current_provided_editor_scripts, array('ghub-custom-cursor-script'));

			return $args;
		}

		/**
		 * 
		 * @param string 	$block_content - Content.
		 * @param array  	$block - Block.
		 * @param WP_Block  $instance - Block instance.
		 */
		public function render_block($block_content, $block, $instance) {
			
			if ( ! class_exists('WP_HTML_Tag_Processor') ) {
				return $block_content;
			}

			$attributes = isset($block['attrs']) ? $block['attrs']:array();
			$has_default_cursor = isset($attributes['ghubIsCustomCursor']) ? $attributes['ghubIsCustomCursor'] : false;
			$has_custom_cursor = isset($attributes['ghubEnableFollowContent']) ? $attributes['ghubEnableFollowContent'] : false;
			$has_enable_follow_content = isset($attributes['ghubEnableFollowContent']) ? $attributes['ghubEnableFollowContent'] : false;

			if( !$has_default_cursor && !$has_custom_cursor ) {
				return $block_content;
			}
			wp_enqueue_script("ghub-custom-cursor-frontend-script");
			wp_enqueue_style('ghub-custom-cursor-frontend-style');
			$cursor_type = isset($attributes['ghubCursorType']) ? $attributes['ghubCursorType'] : "has-text-cursor";
			
			$has_default_cursor_class = $has_default_cursor ? " has-ghub-cursor" : "";

			$unique_id = wp_unique_id();
			
			$processor = new WP_HTML_Tag_Processor( $block_content );

			$processor->next_tag();
			
			// For Classes
			$current_classname = $processor->get_attribute('class');

			$processor->set_attribute('class', $current_classname . $has_default_cursor_class);

			if($has_custom_cursor){
				$processor->set_attribute('data-ghub_id', $unique_id);
			}

			// For Styles
			$current_style =   $processor->get_attribute('style');

			$current_style_array = is_string($current_style) ? explode(";" , $current_style) : array();

			$current_style_array[] = ghub_custom_cursor_wrapper_styles($attributes);
			
			$processor->set_attribute('style', implode(';', $current_style_array));

			$is_image_cursor =  $cursor_type === 'has-image-cursor';
			$is_text_cursor =  $cursor_type === 'has-text-cursor';
			$cursor_text = !empty($attributes['ghubTextCursor']) ? '<p>' . $attributes['ghubTextCursor'] . '</p>' : "<p>Hover Me</p>";
			
			$cursor_div_markup = sprintf(
				'<div
					id="%4$s"
					style="%3$s"
					class="ghub-custom-cursor %1$s %2$s"
					data-ghub_follow_content_position="%6$s"
					data-ghub_follow_content_gap="%7$s"
				>%5$s</div>',
				$is_image_cursor ? "ghub-image-cursor" : "", // 1
				$is_text_cursor ? "ghub-text-cursor" : "", //2
				ghub_custom_cursor_get_styles($attributes), //3
				$unique_id, //4
				$is_text_cursor ? $cursor_text : "", //5
				isset($attributes['ghubFollowContentPosition']) ? $attributes['ghubFollowContentPosition'] : "center center", //6
				isset($attributes['ghubFollowContentGap']) ? $attributes['ghubFollowContentGap'] : "0", //7
			);

			return sprintf("%1s%2s",$processor->get_updated_html(), $has_custom_cursor && $has_enable_follow_content ? $cursor_div_markup : "");
		}
	}

	new Gutenberghub_Custom_Cursor();
}