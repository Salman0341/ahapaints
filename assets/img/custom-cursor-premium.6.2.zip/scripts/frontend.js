class GhubMouseMove {
	constructor() {
		this.customCursorElements = document.querySelectorAll(
			".ghub-custom-cursor"
		);
		this.mouseMoveElements = document.querySelectorAll("[data-ghub_id]");
		this.init();
	}

	init() {
		this.setCursorElementPosition();
		this.mouseMoveElements.forEach((element) => {
			element.addEventListener("mouseenter", () => {
				const dataId = element.getAttribute("data-ghub_id");
				const elementToVisible = document.getElementById(dataId);
				if (!elementToVisible) return;
				elementToVisible.style.visibility = "visible";
				elementToVisible.style.opacity = "1";
			});
		});
		this.mouseMoveElements.forEach((element) => {
			element.addEventListener("mouseleave", () => {
				const dataId = element.getAttribute("data-ghub_id");
				const elementToHide = document.getElementById(dataId);
				if (!elementToHide) return;
				elementToHide.style.visibility = "hidden";
				elementToHide.style.opacity = "0";
			});
		});
	}

	setCursorElementPosition() {
		document.addEventListener("mousemove", (event) => {
			const mouseX = event.x;
			const mouseY = event.y;

			this.customCursorElements.forEach((element, index) => {
				const position = element.dataset.ghub_follow_content_position;
				const gap = Number(element.dataset.ghub_follow_content_gap) ?? 0;
				switch (position) {
					case "center center":
						element.style.left = mouseX - element.clientWidth / 2 + "px";
						element.style.top = mouseY - element.clientHeight / 2 + "px";
						break;
					case "center right":
						element.style.left = mouseX - element.clientWidth - gap + "px";
						element.style.top = mouseY - element.clientHeight / 2 + "px";
						break;
					case "center left":
						element.style.left = mouseX + gap + "px";
						element.style.top = mouseY - element.clientHeight / 2 + "px";
						break;
					case "top left":
						element.style.left = mouseX + gap + "px";
						element.style.top = mouseY + gap + "px";
						break;
					case "top right":
						element.style.left = mouseX - element.clientWidth - gap + "px";
						element.style.top = mouseY + gap + "px";
						break;
					case "top center":
						element.style.left = mouseX - element.clientWidth / 2 + "px";
						element.style.top = mouseY + gap + "px";
						break;
					case "bottom left":
						element.style.left = mouseX + gap + "px";
						element.style.top = mouseY - element.clientHeight - gap + "px";
						break;
					case "bottom right":
						element.style.left = mouseX - element.clientWidth - gap + "px";
						element.style.top = mouseY - element.clientHeight - gap + "px";
						break;
					case "bottom center":
						element.style.left = mouseX - element.clientWidth / 2 + "px";
						element.style.top = mouseY - element.clientHeight - gap + "px";
						break;
					default:
						element.style.left = mouseX - element.clientWidth / 2 + "px";
						element.style.top = mouseY - element.clientHeight / 2 + "px";
						break;
				}
			});
		});
	}
}

window.addEventListener("load", () => {
	new GhubMouseMove();
});
