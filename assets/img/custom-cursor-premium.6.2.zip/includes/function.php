<?php
function has_split_borders($border = []) {
    $sides = ['top', 'right', 'bottom', 'left'];
    foreach ($border as $side => $value) {
         if (in_array($side, $sides)) {
            return true;
        }
    }

    return false;
}

function get_border_css($object) {
    $css = [];

    if (!has_split_borders($object)) {
        $css['top'] = $object;
        $css['right'] = $object;
        $css['bottom'] = $object;
        $css['left'] = $object;
        return $css;
     }

    return $object;
}

function get_single_side_border_value($border, $side) {
    $width = $border[$side]['width'] ?? '';
    $style = $border[$side]['style'] ?? '';
    $color = $border[$side]['color'] ?? '';

    return "{$width} " . ($width && empty($border[$side]['style']) ? 'solid' : $style) . " {$color}";
}

function get_border_variables_css($border, $slug) {
    $border_sides = ['top', 'right', 'bottom', 'left'];
    $borders = [];

    foreach ($border_sides as $side) {
        $side_property = "--ghub-{$slug}-border-{$side}";
        $side_value = get_single_side_border_value($border, $side);
        $borders[$side_property] = $side_value;
    }

    return $borders;
}

function is_value_spacing_preset($value) {

    if (!$value || !is_string($value)) {
        return false;
    }
    return $value === '0' || strpos($value, 'var:preset|spacing|') === 0;
}

function get_spacing_preset_css_var($value) {
    if (!$value) {
        return null;
    }

    $matches = [];
    preg_match('/var:preset\|spacing\|(.+)/', $value, $matches);

    if (empty($matches)) {
        return $value;
    }
    return "var(--wp--preset--spacing--{$matches[1]})";
}

function get_spacing_css($object) {
    $css = [];
    
    foreach ($object as $key => $value) {
         if (is_value_spacing_preset($value)) {
              $css[$key] = get_spacing_preset_css_var($value);
          } else {
               $css[$key] = $value;
          }
     }
     
    return $css;
}



function is_undefined($value) {
    return $value === null || !isset($value) || empty($value);
}

function generate_css_string($styles) {
    $cssString = '';

    foreach ($styles as $key => $value) {
        if (!is_undefined($value) && $value !== false && trim($value) !== '' && trim($value) !== 'undefined undefined undefined' && !empty($value)) {
            $cssString .= $key . ': ' . $value . '; ';
        }
    }

    return $cssString;
}
function ghub_custom_cursor_get_background_color($is_text_cursor, $attributes) {
    $bg_color = '';
    if ($is_text_cursor) {
        if (!empty($attributes['ghubBackgroundColor'])) {
          $bg_color = $attributes['ghubBackgroundColor'];
        } else if (!empty($attributes['ghubBackgroundColor'])) {
          $bg_color = $attributes['ghubGradientBackgroundColor'];
        }
    }
    return $bg_color;
}

function ghub_custom_cursor_get_styles($attributes) {
    if (empty($attributes['ghubIsCustomCursor']) || empty($attributes['ghubEnableFollowContent'])) {
		return "";
	}
    $is_text_cursor = !isset($attributes['ghubCursorType']);
    $image = !empty($attributes['ghubImageCursor']['url']) && isset($attributes['ghubCursorType']) && $attributes['ghubCursorType'] === 'has-image-cursor'
       ? sprintf("url('%1s')",$attributes['ghubImageCursor']['url'])
       : '';
    
    $bg_color = ghub_custom_cursor_get_background_color($is_text_cursor, $attributes);

    $text_color = $is_text_cursor && isset($attributes['ghubTextColor']) ? $attributes['ghubTextColor'] : '';
    
    $text_border = isset($attributes['ghubTextBorder']) ? get_border_css($attributes['ghubTextBorder']) : [];
    
    $text_padding_css = [];
    if ($is_text_cursor) {
         if (isset($attributes['ghubTextPadding'])) {
              $text_padding_css = get_spacing_css($attributes['ghubTextPadding']);
         }
    } else {
         $text_padding_css = [];
    }

    $text_border_variables = isset($text_border) ? get_border_variables_css($text_border, 'custom-cursor') : [];

    $styles = [
        '--ghub-image-cursor'                       => $image,
        '--ghub-custom-cursor-bg-color'             => $bg_color,
        '--ghub-custom-cursor-text-color'           => $text_color,
        '--ghub-custom-cursor-padding-top'          => $text_padding_css['top'] ?? '',
        '--ghub-custom-cursor-padding-left'         => $text_padding_css['left'] ?? '',
        '--ghub-custom-cursor-padding-right'        => $text_padding_css['right'] ?? '',
        '--ghub-custom-cursor-padding-bottom'       => $text_padding_css['bottom'] ?? '',
        '--ghub-custom-cursor-top-left-radius'      => $attributes['ghubTextBorderRadius']['topLeft'] ?? '',
        '--ghub-custom-cursor-top-right-radius'     => $attributes['ghubTextBorderRadius']['topRight'] ?? '',
        '--ghub-custom-cursor-bottom-left-radius'   => $attributes['ghubTextBorderRadius']['bottomLeft'] ?? '',
        '--ghub-custom-cursor-bottom-right-radius'  => $attributes['ghubTextBorderRadius']['bottomRight'] ?? '',
        '--ghub-follow-content-font-size'           => isset($attributes['ghubFollowContentFontSize']) ? $attributes['ghubFollowContentFontSize'] : "",
        '--ghub-follow-content-width'               => isset($attributes['ghubFollowContentWidth']) ? $attributes['ghubFollowContentWidth'] : "",
		'--ghub-follow-content-height'              => isset($attributes['ghubFollowContentHeight']) ? $attributes['ghubFollowContentHeight'] : "",
    ] + $text_border_variables;

    return generate_css_string($styles);
}
function ghub_custom_cursor_wrapper_styles($attributes) {
    if (
        isset($attributes['ghubIsCustomCursor'])  &&
        isset($attributes['ghubCustomCursorType']) &&
        $attributes['ghubCustomCursorType'] === 'custom' &&
        !empty($attributes['ghubDefaultCursorImage'])
    ) {
        return sprintf(
            '--ghub-custom-cursor:url(%s) 10 10, auto;',
            $attributes['ghubDefaultCursorImage']['url']
        );
    } else if (
        isset($attributes['ghubIsCustomCursor']) &&
        !isset($attributes['ghubCustomCursorType']) 
    ) {
        return  sprintf(
            '--ghub-custom-cursor:%s;',
             isset($attributes['ghubDefaultCursor']) ? $attributes['ghubDefaultCursor']:"auto"
        );
    } 
}

?>